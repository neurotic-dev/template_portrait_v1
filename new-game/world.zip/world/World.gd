extends Node2D

onready var cam = $Camera2D
#onready var dplayer = $HUD/DialoguePlayer

export (NodePath) var player_path

var player = null

func _ready():
	player = get_node_or_null(player_path)

#func _input(event):
#	if Input.is_action_just_pressed("ui_accept") and player:
#		if player.target != null and dplayer.is_active() == false and player.state == player.IDLE:
#			dplayer.start_convo(player.target.code)

func _process(delta):
	if player:
		cam.global_position = player.global_position

#func _on_DialoguePlayer_status(_active):
#	if player:
#		player.paused = _active
