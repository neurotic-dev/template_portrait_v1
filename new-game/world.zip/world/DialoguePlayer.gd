extends Control

signal status

onready var STORYMANAGER = $StoryManager
onready var STORYPARSER = $StoryManager/ContentManager/ContentParser
onready var OUTMANAGER = $StoryManager/OutcomeManager
onready var hud = $StoryManager/HUD

var active = false

func _ready():
	var s = Dialogues.new()
	STORYMANAGER.READER.story = s.story
	STORYMANAGER.DIALOGUE = $StoryManager/HUD/DIALOGUE
	STORYMANAGER.PARSER.cnode = STORYMANAGER.DIALOGUE
	
	STORYPARSER.init_filters(Globals.filters)
	show_hud(false)

func is_active():
	return hud.visible

func show_hud(show=true):
	hud.visible = show

func start_convo(key, arc="main"):
	show_hud()
	STORYMANAGER.initialize(arc, key)

func _on_StoryManager_scene_ended(_outcome, _prev,_source):
	show_hud(false)
	emit_signal("status", false)

func _on_StoryManager_scene_started(_scene):
	emit_signal("status", true)
